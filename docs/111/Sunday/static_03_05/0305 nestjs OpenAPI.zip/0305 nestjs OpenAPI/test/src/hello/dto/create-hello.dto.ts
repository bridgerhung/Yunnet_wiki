export class CreateHelloDto {}
