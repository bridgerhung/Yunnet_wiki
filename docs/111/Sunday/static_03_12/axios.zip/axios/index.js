const axios = require('axios');


axios.get('https://opendata.cwb.gov.tw/api/v1/rest/datastore/E-A0015-001?Authorization=CWB-4C17F590-8B81-417B-8EA5-46C9DB077877&timeFrom=2023-03-01T00%3A00%3A00')
/*
    .then((res) => {
        console.log(res);
        console.log("\n-------------");
       
        console.log(res.data);
    });

    */

    .then((res) => {
        console.log(res.data.records.Earthquake);
    });

    